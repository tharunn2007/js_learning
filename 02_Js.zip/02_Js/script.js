let para1 = "lorem1";
let para2 = "lorem2";
let para3 = "lorem3";

document.getElementById("p1") //getelementbyid just 
document.getElementById("p2").textContent = `The second para is ${para2}`;
document.getElementById("p3").textContent = `The third para is ${para3}`;

/////////////////////////////////////////////////

// arithmetic operators (+,-,*,/)
//arithmetic operands (values,variables)

let strength = 43;
strength -= 1; // new 42
window.alert(`  After subtracting 1 ${strength}`)
strength *=2; //new 84
window.alert(`After doubling ${strength}`)
strength **=1.4;
window.alert(`After power ${strength}`)
strength %=2; 
//Short cut based writing is convenient

//increment and decrement 
strength++;
strength--;

/*
 operator precedence
 18: Grouping () and member access . / [] / ?. (left-to-right associativity). 
17: Function calls (), new (with arguments), and import (no associativity). 
15: Postfix increment ++ and decrement -- (no associativity). 
14: Prefix increment ++, decrement --, delete, typeof, void, unary +, -, ~, and ! (right-to-left associativity). 
13: Exponentiation ** (right-to-left associativity). 
12: Multiplication *, division /, and remainder % (left-to-right associativity). 
11: Addition + and subtraction - (left-to-right associativity). 
10: Bitwise shift <<, >>, >>> (left-to-right associativity). 
9: Relational operators <, <=, >, >=, in, instanceof (left-to-right associativity). 
8: Equality operators ==, ===, !=, !== (left-to-right associativity). 
7: Bitwise AND & (left-to-right associativity). 
6: Bitwise XOR ^ (left-to-right associativity).
5: Bitwise OR | (left-to-right associativity).
4: Logical AND && (left-to-right associativity). 
3: Logical OR || and nullish coalescing ?? (left-to-right associativity). 
2: Conditional ? :, assignment =, +=, -=, etc., arrow =>, and spread ... (right-to-left associativity). 
1: Comma operator , (left-to-right associativity).
 */

//For using modulus its a best practice to give a new variable name
let modstregnth = strength%2;
console.log(`modstregnth is${modstregnth}`)






  