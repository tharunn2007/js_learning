///////////////////////////////////////
//USER INPUT   

//EASY WAY- WINDOW PROMPT
//PRO WAY - HTML TEXTBOX

//Easy way:
 
let username = window.prompt("Enter name:"); // comes under a pop up

//professional way
let user2;

user2=document.getElementById("Submit").onclick = function(){
    user2 = document.getElementById("text1").value;
    console.log(user2)
    document.getElementById("h1").textContent=`Hello ${user2}` //textContent - overrides the html text with this written text when executed to the place we want to by get element ID
     
}


/////////////////////////////////////////////////////



//type conversion - change a datatype of a value to another (strings,numbers,boolean)
let age = window.prompt("How old are you?") 
age = Number(age); //WITHOUT TYPE CONVERSION : 24+1 = 241  TYPE: STRING
                   //WITH TYPE CONVERSION : 24+1 = 25 TYPE: NUMBER
age+=1;

//Converting a word to other type:

let x = "WORD";
x= Number(x); // NaN
console.log(x,typeof x);
x= String(x);//WORD
console.log(x,typeof x);
x= Boolean(x);// true  (as long as some values there)
console.log(x,typeof x);


let y = "0";
y= Number(y); // 0 
console.log(y,typeof y);
y= String(y);//"0"
console.log(y,typeof y);
y= Boolean(y);// true  (as long as some values there)
console.log(y,typeof y); 


let z = "";
//FOR EMPTY STRING: number will give ZERO , EMPTY STRING,false for boolean












                    




  