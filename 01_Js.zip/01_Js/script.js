document.getElementById("H2").textContent='Hello'
document.getElementById("P").textContent='I like pizza'
console.log("Hey there")
window.alert("Variables")
//////////////////////////////////////////




//Variables in js
//2 types: 1.Declaration let x;  2.assignment x=100;
let x; //DECLARATION TYPE...once declared cant do it again for the same variables due to syntax error
x=0.34
console.log(x);

//"number" data type - integer and decimal
let age = 19;
let gpa = 3.2;
console.log(`I got ${gpa} gpa when I was ${age} years old`) //TEMPLATE LITERALS -- USE BACKTICKS ``-- ${} FORMAT 
window.alert("Please look into the inspect-> console")
window.alert(`Your GPA is: ${gpa}`)

//typechecking
console.log(typeof age);
console.log(typeof gpa);
window.alert(`The data type of my age is ${typeof age}`);


//String datatype - use doublequotes
let name = "Tharunn";
window.alert(`My name is ${name}`);
console.log(`Type:${name}`) ;
//string datatype is same as in python that can contain any special or digits inside the double quoates

//boolean datatype- true / false
let online = true;
window.alert(`the user is online : ${online}`)


  